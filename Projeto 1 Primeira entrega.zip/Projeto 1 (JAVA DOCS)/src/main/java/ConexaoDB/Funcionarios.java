package ConexaoDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.JOptionPane;


public class Funcionarios{
    
   private Connection conexao;

    public Funcionarios(Connection conexao) {
        this.conexao = conexao;
    }


public void adicionarFuncionario(String nome, String cpf, int idade, String endereco, String login, String Senha) throws SQLException {
        String sql = "INSERT INTO Funcionarios (Nome, cpf, idade, endereco, login, Senha) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, nome);
            stmt.setString(2, cpf );
            stmt.setInt(3, idade);
            stmt.setString(4, endereco);
            stmt.setString(5, login);
            stmt.setString(6, Senha);
            stmt.executeUpdate();
        }
    }

        public ResultSet obterFuncionarios() throws SQLException {
        String sql = "SELECT * FROM Funcionarios";
        PreparedStatement stmt = conexao.prepareStatement(sql);
        return stmt.executeQuery();
 
    
        }

public static class Funcionario {
        public int id;
        public String nome;
        public String cpf;
        public int idade;
        public String endereco;
        public String login;
        public String Senha;

        public Funcionario(String nome, String cpf, int idade, String endereco, String login, String Senha) {
            this.id = id;
            this.nome = nome;
            this.cpf = cpf;
            this.idade = idade;
            this.endereco = endereco;
            this.login = login;
            this.Senha = Senha;
        }

 
    }

}


