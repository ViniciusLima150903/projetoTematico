package ConexaoDB; // Certifique-se de usar o pacote correto

import ConexaoDB.MateriaisReciclaveisDAO;
import ConexaoDB.dbConnection;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class IniciaBancoConexao {

   
    public IniciaBancoConexao() throws SQLException {//metodo para chamar a funçao de conexao do banco
        conectarBanco();
    }
    

    
    public void conectarBanco() throws SQLException {//Metodo de conexao do banco
        try {
            Connection conexao = dbConnection.getConnection();
            MateriaisReciclaveisDAO dao = new MateriaisReciclaveisDAO(conexao);
            conexao.close(); // Fechamento da conexao com o DB

        } catch (SQLException e) { // Excessao para caso nao conecte

            System.out.println("Falha ao conectar ao banco de dados PostgreSQL.");
            e.printStackTrace();
       
        }
    }
    
    public void adicionarItem()throws SQLException{
        try {
            Connection conexao = dbConnection.getConnection();
            MateriaisReciclaveisDAO dao = new MateriaisReciclaveisDAO(conexao);
            conexao.close(); // Fechamento da conexao com o DB

        } catch (SQLException e) { // Excessao para caso nao conecte

            System.out.println("Falha ao conectar ao banco de dados PostgreSQL.");
            e.printStackTrace();
       
        }
    }
    
 
}
