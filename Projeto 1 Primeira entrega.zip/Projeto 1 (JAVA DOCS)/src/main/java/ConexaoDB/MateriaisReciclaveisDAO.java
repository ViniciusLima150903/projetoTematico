package ConexaoDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class MateriaisReciclaveisDAO {

    private Connection conexao;

    public MateriaisReciclaveisDAO(Connection conexao) {
        this.conexao = conexao;
    }

    public void adicionarMaterialReciclavel(String nome, String tipoMaterial, int modoVenda, double preco) throws SQLException {
        String sql = "INSERT INTO MateriaisReciclaveis (Nome, TipoMaterial, ModoVenda, Preco) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, nome);
            stmt.setString(2, tipoMaterial);
            
            stmt.setInt(3, modoVenda);
            stmt.setDouble(4, preco);
            stmt.executeUpdate();
        }
    }
    
    public List<MaterialReciclavel> listarMateriaisReciclaveis() throws SQLException {
        List<MaterialReciclavel> materiais = new ArrayList<>();
        String sql = "SELECT * FROM MateriaisReciclaveis";
        try (PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                int id = rs.getInt("MaterialID");
                String nome = rs.getString("Nome");
                String tipoMaterial = rs.getString("TipoMaterial");
                int modoVenda = rs.getInt("ModoVenda");
                double preco = rs.getDouble("Preco");
                MaterialReciclavel material = new MaterialReciclavel(id, nome, tipoMaterial, modoVenda, preco);
                materiais.add(material);
    }
        }
    
        return materiais;
        
     
    }
    
    public ResultSet obterMateriaisReciclaveis() throws SQLException {
        String sql = "SELECT * FROM MateriaisReciclaveis";
        PreparedStatement stmt = conexao.prepareStatement(sql);
        return stmt.executeQuery();
 
    
}
    
    public void removerMaterialReciclavel(String nomeMaterial) throws SQLException {
    String sql = "DELETE FROM MateriaisReciclaveis WHERE Nome = ?";
    try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
        stmt.setString(1, nomeMaterial);
        stmt.executeUpdate();
    }
}

    
    public void adicionarQuantidadeMaterial(int materialID, int quantidadeAdicional) throws SQLException {
    // Verificar se a quantidade adicionada é um número válido
    while (quantidadeAdicional <= 0) {
        JOptionPane.showMessageDialog(null,"valor" + quantidadeAdicional + "é um valor invalido, tente novamente!");
        String input = JOptionPane.showInputDialog(null, "Por favor, insira uma quantidade válida (um número positivo):");
        try {
            quantidadeAdicional = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            // Capturar exceção se a entrada não puder ser convertida para um número inteiro
            quantidadeAdicional = -1; // Define um valor inválido para continuar o loop
        }
    }

    // Verificar se a ID do material existe no banco de dados
    while (!materialExists(materialID)) {
        JOptionPane.showMessageDialog(null,"O material com " + materialID + " não foi encontrado");
        String input = JOptionPane.showInputDialog(null, "Por favor, insira um ID de material existente:");
        try {
            materialID = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            // Capturar exceção se a entrada não puder ser convertida para um número inteiro
            materialID = -1; // Define um valor inválido para continuar o loop
        }
    }

    // Atualizar a quantidade no banco de dados
    String sql = "UPDATE MateriaisReciclaveis SET Quantidade = Quantidade + ? WHERE MaterialID = ?";
    try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
        stmt.setInt(1, quantidadeAdicional);
        stmt.setInt(2, materialID);
        stmt.executeUpdate();
        System.out.println("Quantidade atualizada com sucesso.");
    }
}
    
        public void removerQuantidadeMaterial(int materialID, int quantidadeAdicional) throws SQLException {
    // Verificar se a quantidade adicionada é um número válido
    while (quantidadeAdicional <= 0) {
        JOptionPane.showMessageDialog(null,"valor" + quantidadeAdicional + "é um valor invalido, tente novamente!");
        String input = JOptionPane.showInputDialog(null, "Por favor, insira uma quantidade válida (um número positivo):");
        try {
            quantidadeAdicional = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            // Capturar exceção se a entrada não puder ser convertida para um número inteiro
            quantidadeAdicional = -1; // Define um valor inválido para continuar o loop
        }
    }

    // Verificar se a ID do material existe no banco de dados
    while (!materialExists(materialID)) {
        JOptionPane.showMessageDialog(null,"O material com " + materialID + " não foi encontrado");
        String input = JOptionPane.showInputDialog(null, "Por favor, insira um ID de material existente:");
        try {
            materialID = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            // Capturar exceção se a entrada não puder ser convertida para um número inteiro
            materialID = -1; // Define um valor inválido para continuar o loop
        }
    }

    // Atualizar a quantidade no banco de dados
    String sql = "UPDATE MateriaisReciclaveis SET Quantidade = Quantidade - ? WHERE MaterialID = ?";
    try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
        stmt.setInt(1, quantidadeAdicional);
        stmt.setInt(2, materialID);
        stmt.executeUpdate();
        System.out.println("Quantidade atualizada com sucesso.");
    }
}


// Método para verificar se o material com a ID especificada existe no banco de dados
   private boolean materialExists(int materialID) throws SQLException {
    String sql = "SELECT MaterialID FROM MateriaisReciclaveis WHERE MaterialID = ?";
    try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
        stmt.setInt(1, materialID);
        try (ResultSet rs = stmt.executeQuery()) {
            return rs.next(); // Retorna true se encontrar uma linha (material) com a ID especificada
        }
    }
}


    public static class MaterialReciclavel {
        public int id;
        public String nome;
        public String tipoMaterial;
        public int modoVenda;
        public double preco;

        public MaterialReciclavel(int id, String nome, String tipoMaterial, int modoVenda, double preco) {
            this.id = id;
            this.nome = nome;
            this.tipoMaterial = tipoMaterial;
            this.modoVenda = modoVenda;
            this.preco = preco;
        }

 
    }
}
