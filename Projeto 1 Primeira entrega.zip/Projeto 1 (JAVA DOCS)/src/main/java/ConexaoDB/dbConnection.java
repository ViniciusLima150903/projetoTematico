/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ConexaoDB;

/**
 *
 * @author Gabriel Santos
*/

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class dbConnection {

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("org.postgresql.Driver");
            Connection conexao = DriverManager.getConnection("jdbc:postgresql://localhost:5432/PROJETOTEm1", "postgres", "1332");
            System.out.println("Conexão bem-sucedida ao banco de dados PostgreSQL.");
            return conexao;
        } catch (ClassNotFoundException e) {
            System.out.println("Não foi possível carregar o driver JDBC do PostgreSQL.");
            e.printStackTrace();
            return null;
        }
    }
}

