package Main; // Certifique-se de usar o pacote correto

/*

import ConexaoDB.*;
import ConexaoDB.MateriaisReciclaveisDAO;
import java.sql.Connection;
import java.sql.SQLException;

public class Testebanco {

   public static void main(String[] args) throws SQLException {
        IniciaBancoConexao conexao = new IniciaBancoConexao();
        conexao.conectarBanco();
    }
}
*/