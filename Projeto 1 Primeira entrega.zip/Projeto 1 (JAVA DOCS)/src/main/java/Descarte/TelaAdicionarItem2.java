package Descarte;

import ConexaoDB.MateriaisReciclaveisDAO;
import ConexaoDB.dbConnection;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class TelaAdicionarItem2 extends javax.swing.JFrame {

    public TelaAdicionarItem2() {
        initComponents();
    }
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jToggleButton1 = new javax.swing.JToggleButton();
        jToggleButton2 = new javax.swing.JToggleButton();
        jToggleButton3 = new javax.swing.JToggleButton();
        caixaNome = new java.awt.TextField();
        caixaTipoMaterial = new java.awt.TextField();
        caixaQtd = new java.awt.TextField();
        caixaPreco = new java.awt.TextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setType(java.awt.Window.Type.POPUP);

        jToggleButton1.setText("Voltar");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        jToggleButton2.setText("Limpar");
        jToggleButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton2ActionPerformed(evt);
            }
        });

        jToggleButton3.setText("Adicionar");
        jToggleButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton3ActionPerformed(evt);
            }
        });

        caixaNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                caixaNomeActionPerformed(evt);
            }
        });

        caixaTipoMaterial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                caixaTipoMaterialActionPerformed(evt);
            }
        });

        jLabel1.setText("Nome:");

        jLabel2.setText("Tipo Material");

        jLabel3.setText("Tipo de item");

        jLabel4.setText("Preço");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1)
                            .addComponent(jLabel3)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(37, 37, 37)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(caixaNome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(caixaQtd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(caixaTipoMaterial, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(caixaPreco, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(235, 235, 235)
                        .addComponent(jToggleButton1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(163, 163, 163)
                        .addComponent(jToggleButton2)
                        .addGap(82, 82, 82)
                        .addComponent(jToggleButton3)))
                .addContainerGap(146, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(caixaNome, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(caixaTipoMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(caixaQtd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(caixaPreco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)))
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jToggleButton3)
                    .addComponent(jToggleButton2))
                .addGap(37, 37, 37)
                .addComponent(jToggleButton1)
                .addGap(23, 23, 23))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
        TelaMenuOpções2 tela2 = new TelaMenuOpções2();
        tela2.setVisible(true);
        this.setVisible(false); // Oculta a TelaInicial
        
    }//GEN-LAST:event_jToggleButton1ActionPerformed

    private void jToggleButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton2ActionPerformed

    }//GEN-LAST:event_jToggleButton2ActionPerformed

    private void jToggleButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton3ActionPerformed
        
        String nome = caixaNome.getText();
    String tipoMaterial = caixaTipoMaterial.getText();
    int modoVenda = Integer.parseInt(caixaQtd.getText());
    while(modoVenda != 1 && modoVenda != 2) {
        JOptionPane.showMessageDialog(this, "Valor incorreto para o Modo de Venda. Por favor, escolha 1 para unidade ou 2 para quantidade.", "Erro", JOptionPane.ERROR_MESSAGE);
        // Pedir ao usuário para inserir o valor novamente
        caixaQtd.setText(""); // Limpar o campo de texto
        String input = JOptionPane.showInputDialog(this, "Digite o modo de venda (1 para unidade, 2 para quantidade):");
        modoVenda = Integer.parseInt(input);
    }
    double preco = Double.parseDouble(caixaPreco.getText());

    try {
        // Conectar ao banco de dados
        Connection conexao = dbConnection.getConnection();
        MateriaisReciclaveisDAO dao = new MateriaisReciclaveisDAO(conexao);

        // Adicionar o material reciclável usando o método do DAO
        dao.adicionarMaterialReciclavel(nome, tipoMaterial, modoVenda, preco);
        
        // Exibir uma mensagem de sucesso
        JOptionPane.showMessageDialog(this, "Material adicionado com sucesso.");
        
        // Limpar os campos após a adição
        caixaNome.setText("");
        caixaTipoMaterial.setText("");
        caixaQtd.setText("");
        caixaPreco.setText("");
    } catch (SQLException e) {
        // Em caso de erro, exibir uma mensagem de erro
        JOptionPane.showMessageDialog(this, "Erro ao adicionar material: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
    }
    
    }//GEN-LAST:event_jToggleButton3ActionPerformed

    private void caixaNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_caixaNomeActionPerformed
      
    }//GEN-LAST:event_caixaNomeActionPerformed

    private void caixaTipoMaterialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_caixaTipoMaterialActionPerformed
        
    }//GEN-LAST:event_caixaTipoMaterialActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.TextField caixaNome;
    private java.awt.TextField caixaPreco;
    private java.awt.TextField caixaQtd;
    private java.awt.TextField caixaTipoMaterial;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JToggleButton jToggleButton2;
    private javax.swing.JToggleButton jToggleButton3;
    // End of variables declaration//GEN-END:variables
}
